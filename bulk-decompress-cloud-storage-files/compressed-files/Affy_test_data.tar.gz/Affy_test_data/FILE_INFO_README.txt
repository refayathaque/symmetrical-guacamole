Affy Array:HG-U133_Plus_2

Two Human Cancer Cell Line LN and C4 profiled in duplicate
